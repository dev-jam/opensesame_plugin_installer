
__title__ = 'pylink'
__description__ = 'Python module for interfacing SR Research EyeLink eye trackers'
__url__ = 'https://www.sr-support.com'
__version__ = '2.1.1197.0'
__author__ = 'SR Research.com'
__author_email__ = 'support@sr-research.com'
__license__ = 'SR Research Ltd.'
__copyright__ = 'Copyright 2024 SR Research Ltd.'
